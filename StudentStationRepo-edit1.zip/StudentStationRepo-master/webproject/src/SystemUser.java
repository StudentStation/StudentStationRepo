public class SystemUser extends SimpleFormInsert {
	int userID = 0;
}