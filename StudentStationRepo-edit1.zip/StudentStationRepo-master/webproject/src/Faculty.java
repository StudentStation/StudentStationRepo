public class Faculty extends SimpleFormSearch {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}