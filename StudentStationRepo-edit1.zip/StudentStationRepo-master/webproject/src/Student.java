
public class Student extends SimpleFormInsert {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1087491901079636834L;
	String name;
	String email;
	String major;
	String minor;
	String org;
	String grad;
}